package com.capgemini;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class MainApp {

	public static void main(String[] args) {
		//addDetails();
		//showAll();
		showByAuthor();
             
	}

	private static void showByAuthor() {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "Lab2" );
	      EntityManager entitymanager = emfactory.createEntityManager();
	      Query query = entitymanager.createNamedQuery("find book by id");
	      
	      query.setParameter("id", 51);
	      List<BookA> list = query.getResultList( );
	      
	      for( BookA e:list ){
	         System.out.print("Book ID :" + e.getISBN());
	         System.out.print("\t Book Name :" + e.getTitle());
	         System.out.println("\t Bokk Price :"+e.getPrice());
	      }
		
	}

	private static void showAll() {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "Lab2" );
	      EntityManager entitymanager = emfactory.createEntityManager();

	      //Scalar function
	      Query query = entitymanager.createQuery("Select e from AuthorA e");
	      List<AuthorA> list = (List<AuthorA>)query.getResultList();

	      for(AuthorA e:list) {
	    	  System.out.println("Author Id : "+e.getId());
	         System.out.println("Author Name : "+e.getName());
	      }
	      
	      Query query1 = entitymanager.createQuery("Select e1 from BookA e1");
	    	      List<BookA> list1 = (List<BookA>)query1.getResultList();

	    	      for(BookA e1:list1) {
	    	    	  System.out.println("Book Id : "+e1.getISBN());
	    	         System.out.println("Book Name : "+e1.getTitle());
	    	         System.out.println("Book Price : "+e1.getPrice());
	    	      }

	      
	}

	private static void addDetails() {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Lab2");  
        EntityManager em=emf.createEntityManager();  
          
        em.getTransaction().begin();  
        BookA book = new BookA();
        book.setTitle("JAVA");
        book.setPrice(1000);
        
        BookA book1 = new BookA();
        book1.setTitle("Python");
        book1.setPrice(2000);
        
        em.persist(book);
        em.persist(book1);
        
        List<BookA> list = new ArrayList<BookA>();
        list.add(book);
        list.add(book1);
        
        AuthorA author = new AuthorA();
        author.setName("manas");
        author.setList(list);
        
        em.persist(author);
        
        em.getTransaction().commit();  
        em.close();  
        emf.close();  
		
	}

}
