package com.capgemini.payment.service;
import java.math.BigDecimal;

import com.capgemini.payment.beans.Customer;
import com.capgemini.payment.exception.InsufficientWalletBalanceException;
import com.capgemini.payment.exception.PhoneNumberAlreadyExist;
import com.capgemini.payment.exception.TransactionFailedException;
import com.capgemini.payment.exception.WalletAccountDoesNotExist;

public interface WalletService {
public Customer createAccount(Customer customer) throws PhoneNumberAlreadyExist, TransactionFailedException;
public Customer showBalance (String mobileno) throws WalletAccountDoesNotExist;
public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, BigDecimal amount) throws InsufficientWalletBalanceException, WalletAccountDoesNotExist;
public Customer depositAmount (String mobileNo,BigDecimal amount ) throws WalletAccountDoesNotExist;
public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws InsufficientWalletBalanceException, WalletAccountDoesNotExist;
}
