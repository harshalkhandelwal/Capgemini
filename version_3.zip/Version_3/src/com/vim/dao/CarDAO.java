package com.vim.dao;

import java.util.*;

import com.cg.dto.*;

//Follow TODOs (if available)
/**
 * 
 * This is a CarDAO class
 * @see java.lang.Object
 * @author Abhishek
 * 
 *
 */
public interface CarDAO 
{
    public List<CarDTO> findAll(); 
    public CarDTO findById(int id);
    public boolean create(CarDTO car);
    public boolean update(CarDTO car);
    public boolean delete(String[] ids);
}