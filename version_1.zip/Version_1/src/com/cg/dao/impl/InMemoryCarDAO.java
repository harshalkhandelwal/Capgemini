package com.cg.dao.impl;

import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.collections.map.HashedMap;

import com.cg.dao.CarDAO;
import com.cg.dto.CarDTO;

public class InMemoryCarDAO implements CarDAO {

	 Map<Integer,CarDTO> data=new HashMap<Integer,CarDTO>();
	@Override
	public List<CarDTO> findAll() {
		// TODO Auto-generated method stub
		List<CarDTO> list=new ArrayList<CarDTO>(data.values());
		return list;
	}

	@Override
	public CarDTO findById(int id) {
		// TODO Auto-generated method stub
		if(data.containsKey(id))
		{
		CarDTO dto=data.get(id);
		return dto;
		}
		else return null;
	}

	@Override
	public void create(CarDTO car) {
		// TODO Auto-generated method stub
		data.put(car.getId(), car);
		
	}

	@Override
	public void update(CarDTO car) {
		// TODO Auto-generated method stub
		data.put(car.getId(),car);
		
	}

	@Override
	public void delete(String[] ids) {
		// TODO Auto-generated method stub
		for(int i=0;i<ids.length;i++)
		{System.out.println("hgfrghf");
			int temp=Integer.parseInt(ids[i]);
			if(data.containsKey(temp)) {
				System.out.println("zgdsdj");
				data.remove(temp);
			}
			
		}
	}
}
