package com.capg.loginPageDemo;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "html:reports" }, features="D:\\HARSHAL\\repos\\eclipse-workspace-for git\\Module3-harshal-bdd\\src\\test\\resources\\login.feature")
public class TestRunnerLoginPage {

}
