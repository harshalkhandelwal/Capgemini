package com.capg.loginPageDemo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capg.loginPageBean.LoginPage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefsLoginPage {
	
	private static WebDriver driver;
	private LoginPage obj1;
	
	@Before
	public void setup(){
		String projectLocation = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLocation + "\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
//		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		
	}

	@Given("^user is on hotel booking login page$")
	public void user_is_on_hotel_booking_login_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
	
		driver.get("D:\\HARSHAL\\repos\\eclipse-workspace-for git\\Module3-harshal-bdd\\src\\main\\login.html");
		obj1 = new LoginPage(driver);
		
		
	   // throw new PendingException();
	}
	
	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		WebElement element = driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1"));
		Thread.sleep(2000);
		System.out.println(element.getText());
		assertEquals("Hotel Booking Application", element.getText());
		
	}

	@When("^user enter invalid username and clicks the button$")
	public void user_enter_invalid_username_and_clicks_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		obj1.setUname("sdjfs");
		Thread.sleep(2000);
		obj1.setPassword("capg1234");
		//driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		obj1.setButton();
	}

	@Then("^Alert message is displayed for username$")
	public void alert_message_is_displayed_for_username() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		
		String alertMsg = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("***"+alertMsg);
		assertEquals("Invalid login! Please try again!", alertMsg);
	}
	
	@When("^user enter invalid password and clicks the button$")
	public void user_enter_invalid_password_and_clicks_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj1.setUname("capgemini");
		Thread.sleep(2000);
		obj1.setPassword("dfjkhjkhh");
		Thread.sleep(2000);
		obj1.setButton();
	}

	@Then("^Alert message is displayed for password$")
	public void alert_message_is_displayed_for_password() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		String alertMsg = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("***"+alertMsg);
		assertEquals("Invalid login! Please try again!", alertMsg);
	}
	
	
	
	
	@When("^user enter all invalid credentials and clicks the button$")
	public void user_enter_all_invalid_credentials_and_clicks_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		obj1.setUname("harshal");
		Thread.sleep(2000);
		obj1.setPassword("khandelwal");
		Thread.sleep(2000);
		obj1.setButton();
	}

	@Then("^Alert message is displayed$")
	public void alert_message_is_displayed() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		String alertMsg = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("***"+alertMsg);
		assertEquals("Invalid login! Please try again!", alertMsg);
	}

	@When("^user enter all valid credentials and clicks the button$")
	public void user_enter_all_valid_credentials_and_clicks_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		obj1.setUname("capgemini");
		Thread.sleep(2000);
		obj1.setPassword("capg1234");
		Thread.sleep(2000);
		obj1.setButton();
	}

	@Then("^Navigate to hotel booking page$")
	public void navigate_to_hotel_booking_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		driver.navigate().to("D:\\HARSHAL\\repos\\eclipse-workspace-for git\\Module3-harshal-bdd\\src\\main\\hotelbooking.html");
		Thread.sleep(2000);
		
	}
	
	@After
	public void tearDown(){
		driver.quit();
	}


}
