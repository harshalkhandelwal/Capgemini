package com.capg.loginPageDemo;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capg.loginPageBean.LoginPage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefsLoginPage {
	
	private WebDriver driver;
	private LoginPage obj1;

	@Given("^user is on hotel booking login page$")
	public void user_is_on_hotel_booking_login_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("WebDriver.chrome.driver", "D:\\HARSHAL\\repos\\eclipse-workspace-for git\\Module3-harshal-bdd\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		obj1 = new LoginPage();
		driver.get("D:\\HARSHAL\\repos\\eclipse-workspace-for git\\Module3-harshal-bdd\\src\\main\\login.html");
		
	   // throw new PendingException();
	}

	@When("^user enter invalid username and clicks the button$")
	public void user_enter_invalid_username_and_clicks_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		obj1.setUname("");
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		obj1.setButton();
	}

	@Then("^Alert message is displayed for username$")
	public void alert_message_is_displayed_for_username() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		
		String alertMsg = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("***"+alertMsg);
		driver.close();

	}


}
