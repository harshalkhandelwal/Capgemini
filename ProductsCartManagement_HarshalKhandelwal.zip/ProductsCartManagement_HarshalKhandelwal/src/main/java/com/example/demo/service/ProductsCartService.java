package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.ProductsCartDTO;


public interface ProductsCartService {
	
	//defining all CRUD operation methods here

	public List<ProductsCartDTO> viewProducts();
	public ProductsCartDTO createProduct(ProductsCartDTO productscartdto);
	public ProductsCartDTO findProduct(String id);
	public ProductsCartDTO updateProduct(String id, ProductsCartDTO productscartdto);
	public ProductsCartDTO deleteProduct(String id);

}
