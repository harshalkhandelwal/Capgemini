package HotelBooking1;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.HotelBookingPageFactory;
import pageBean.LoginPageFactory;
import pom.Browser;

public class StepDefsHotelBooking {
	// private WebDriver driver;

	// private HotelBookingPageFactory factory = new HotelBookingPageFactory();
	// private LoginPageFactory login = new LoginPageFactory();

	private HotelBookingPageFactory factory;;
	private LoginPageFactory login;;

	@Before
	public void setup() {
		Browser browser = new Browser();

		factory = new HotelBookingPageFactory(browser);
		login = new LoginPageFactory(browser);
	}

	/*
	 * @Before public void setup() { String projectLocation =
	 * System.getProperty("user.dir"); System.setProperty("webdriver.chrome.driver",
	 * projectLocation + "\\lib\\chromedriver.exe"); driver = new ChromeDriver();
	 * 
	 * }
	 */

	@Given("^User is on hotel login page$")
	public void user_is_on_hotel_login_page() throws Throwable {

		login.goTo();
		login.getBrowser().driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@Then("^check the title of the login page$")
	public void checkTheTitleOfTheLoginPage() throws Throwable {
		assertTrue(login.isAt());
		login.getBrowser().driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);

	}

	@When("^user enters all valid login data$")
	public void userEntersAllValidLoginData() throws Throwable {

		login.setPfuname("capgemini");
		Thread.sleep(1000);
		login.setPfpwd("capg1234");
		Thread.sleep(1000);
		login.getBrowser().driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);

		login.setPfbutton();
		Thread.sleep(1000);

	}

	@And("^clicks the Login button$")
	public void clicksTheLoginButton() throws Throwable {
		login.setPfbutton();
	}

	@Then("^display Login alert msg$")
	public void displayLoginAlertMsg() throws Throwable {

		String alertMessage = login.getBrowser().driver.findElement(By.id("userErrMsg")).getText();
		assertEquals("* Please enter userName.", alertMessage);

		Thread.sleep(1000);
	}

	@Then("^display Login pwd alert msg$")
	public void display_pwd_alert_msg() throws Throwable {

		String alertMessage = login.getBrowser().driver.findElement(By.id("pwdErrMsg")).getText();

		assertEquals("* Please enter password.", alertMessage);

		Thread.sleep(1000);
		// System.out.println("******" + alertMessage);

	}

	@Then("^display alert box msg$")
	public void display_pwd_alert_box_msg() throws Throwable {
		Alert alert = login.getBrowser().driver.switchTo().alert();
		assertEquals("Invalid login! Please try again!", alert.getText());
		System.out.println(alert.getText());
		Thread.sleep(1000);
		/*
		 * System.out.println("******" + alert.getText());
		 */
	}

	@Then("^navigate to booking page$")
	public void navigateToBookingPage() throws Throwable {

		factory.goTo();
		assertTrue(factory.isAt());
		factory.getBrowser().driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);

	}

	@When("^user leaves userName blank$")
	public void user_leaves_userName_blank() throws Throwable {
		login.setPfuname("");
		Thread.sleep(1000);
	}

	@When("^user leaves password blank and clicks the button$")
	public void user_leaves_password_blank_and_clicks_the_button() throws Throwable {
		login.setPfuname("capgemini");
		Thread.sleep(1000);
		login.setPfpwd("");
		Thread.sleep(1000);
		login.setPfbutton();
	}

	@When("^user enters incorrect userName$")
	public void user_enters_incorrect_userName() throws Throwable {
		login.setPfuname("Capgemini");
		login.setPfpwd("capg1234");
		Thread.sleep(1000);
		login.setPfbutton();
	}

	@When("^user enters incorrect password$")
	public void user_enters_incorrect_password() throws Throwable {
		login.setPfuname("capgemini");
		login.setPfpwd("Capg1234");
		Thread.sleep(1000);
		login.setPfbutton();
	}

	@Given("^User is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Throwable {
		factory.getBrowser().driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);

		factory.goTo();

	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Exception {
		assertTrue(factory.isAt());
		factory.getBrowser().driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);

		/*
		 * String title = driver.getTitle(); assertEquals("Hotel Booking", title);
		 */
		/*
		 * if(title.contentEquals("Hotel Booking"))
		 * System.out.println("****** Title Matched"); else
		 * System.out.println("****** Title NOT Matched");
		 * driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		 */
		// driver.close();
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Exception {
		factory.setPffname("Neelima");
		Thread.sleep(1000);
		factory.setPflname("Padmawar");
		Thread.sleep(1000);
		factory.setPfemail("neel.p@gmail.com");
		Thread.sleep(1000);
		factory.setPfmobile("8908765432");
		Thread.sleep(1000);
		factory.setPfcity("Pune");
		Thread.sleep(1000);
		factory.setPfstate("Maharashtra");
		Thread.sleep(1000);
		factory.setPfpersons(7);
		Thread.sleep(1000);
		factory.setPfcardholder("Neelima Padmawar");
		Thread.sleep(1000);
		factory.setPfdebit("5678567867897890");
		Thread.sleep(1000);
		factory.setPfcvv("078");
		Thread.sleep(1000);
		factory.setPfmonth("6");
		Thread.sleep(1000);
		factory.setPfyear("2020");
		factory.getBrowser().driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);

		factory.setPfbutton();
		Thread.sleep(1000);
		// driver.close();
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Exception {
		factory.getBrowser().driver.navigate()
				.to("file:///D:\\\\Users\\\\akhilsri\\\\Downloads\\\\New folder/success.html");
		// driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		// assertEquals("Payment Details", Browser.driver.getTitle());
		// driver.close();
	}

	@When("^user leaves first Name blank$")
	public void user_leaves_first_Name_blank() throws Exception {
		factory.setPffname("");
		Thread.sleep(1000);

	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
		factory.setPfbutton();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Exception {
		String alertMessage = factory.getBrowser().driver.switchTo().alert().getText();
		Thread.sleep(1000);
		// driver.switchTo().alert().accept();
		System.out.println("******" + alertMessage);
		assertTrue(alertMessage.length() > 0);
		// assertEquals("", alertMessage);
		// driver.close();
	}

	@When("^user leaves last Name blank and clicks the button$")
	public void user_leaves_last_Name_blank_and_clicks_the_button() throws Exception {
		factory.setPffname("Neelima");
		Thread.sleep(1000);
		factory.setPflname("");
		Thread.sleep(1000);
		factory.setPfbutton();

	}

	@When("^user enters all data$")
	public void user_enters_all_data() throws Exception {
		factory.setPffname("Neelima");
		Thread.sleep(1000);
		factory.setPflname("Padmawar");
		Thread.sleep(1000);
		factory.setPfmobile("8908765432");
		Thread.sleep(1000);
		factory.setPfcity("Pune");
		Thread.sleep(1000);
		factory.setPfstate("Maharashtra");
		Thread.sleep(1000);
		factory.setPfpersons(7);
		Thread.sleep(1000);
		factory.setPfcardholder("Neelima Padmawar");
		Thread.sleep(1000);
		factory.setPfdebit("5678567867897890");
		Thread.sleep(1000);
		factory.setPfcvv("078");
		Thread.sleep(1000);
		factory.setPfmonth("6");
		Thread.sleep(1000);
		factory.setPfyear("2020");
		Thread.sleep(1000);
	}

	@When("^user enters incorrect email format and clicks the button$")
	public void user_enters_incorrect_email_format_and_clicks_the_button() throws Exception {
		factory.setPfemail("neel@.com");
		Thread.sleep(1000);
		factory.setPfbutton();
	}

	@When("^user leaves MobileNo blank and clicks the button$")
	public void user_leaves_MobileNo_blank_and_clicks_the_button() throws Exception {
		factory.setPffname("Neelima");
		Thread.sleep(1000);
		factory.setPflname("Padmawar");
		Thread.sleep(1000);
		factory.setPfemail("neel.p@gmail.com");
		Thread.sleep(1000);
		factory.setPfmobile("");
		Thread.sleep(1000);
		factory.setPfbutton();
	}

	@When("^user enters incorrect mobileNo format and clicks the button$")
	public void user_enters_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Exception {
		factory.setPffname("Neelima");
		Thread.sleep(1000);
		factory.setPflname("Padmawar");
		Thread.sleep(1000);
		factory.setPfemail("neel.p@gmail.com");
		Thread.sleep(1000);

		List<String> objList = arg1.asList(String.class);
		// factory.setPfmobile(objList); Thread.sleep(1000);
		factory.setPfbutton();

		for (int i = 0; i < objList.size(); i++) {
			if (Pattern.matches("^[7-9]{1}[0-9]{9}$", objList.get(i))) {
				System.out.println("***** Matched" + objList.get(i) + "*****");
			} else {
				System.out.println("***** NOT Matched" + objList.get(i) + "*****");
			}
		}

	}

	@When("^user doesnot select city$")
	public void user_doesnot_select_city() throws Exception {
		factory.setPffname("Neelima");
		Thread.sleep(1000);
		factory.setPflname("Padmawar");
		Thread.sleep(1000);
		factory.setPfemail("neel.p@gmail.com");
		Thread.sleep(1000);
		factory.setPfmobile("8908765432");
		Thread.sleep(1000);
		factory.setPfcity("Select City");
		Thread.sleep(1000);
		factory.setPfbutton();
	}

	@When("^user doesnot select state$")
	public void user_doesnot_select_state() throws Exception {
		factory.setPffname("Neelima");
		Thread.sleep(1000);
		factory.setPflname("Padmawar");
		Thread.sleep(1000);
		factory.setPfemail("neel.p@gmail.com");
		Thread.sleep(1000);
		factory.setPfmobile("8908765432");
		Thread.sleep(1000);
		factory.setPfcity("Pune");
		Thread.sleep(1000);
		factory.setPfstate("Select State");
		Thread.sleep(1000);
		factory.setPfbutton();
	}

	@When("^user enters (\\d+)$")
	public void user_enters(int arg1) throws Exception {
		factory.setPffname("Neelima");
		Thread.sleep(1000);
		factory.setPflname("Padmawar");
		Thread.sleep(1000);
		factory.setPfemail("neel.p@gmail.com");
		Thread.sleep(1000);
		factory.setPfmobile("8908765432");
		Thread.sleep(1000);
		factory.setPfcity("Pune");
		Thread.sleep(1000);
		factory.setPfstate("Maharashtra");
		Thread.sleep(1000);
		factory.setPfpersons(arg1);
		Thread.sleep(2000);
	}

	@Then("^allocate rooms such that (\\d+) room for minimum (\\d+) guests$")
	public void allocate_rooms_such_that_room_for_minimum_guests(int arg1, int arg2) throws Throwable {
		if (arg2 <= 3) {
			System.out.println("***** 1 room");
			assertEquals(1, arg1);
		} else if (arg2 <= 6) {
			System.out.println("***** 2 rooms");
			assertEquals(2, arg1);
		} else if (arg2 <= 9) {
			System.out.println("***** 3 rooms");
			assertEquals(3, arg1);
		}

	}

	@When("^user leaves CardHolderName blank and clicks the button$")
	public void user_leaves_CardHolderName_blank_and_clicks_the_button() throws Exception {
		factory.setPffname("Neelima");
		Thread.sleep(1000);
		factory.setPflname("Padmawar");
		Thread.sleep(1000);
		factory.setPfemail("neel.p@gmail.com");
		Thread.sleep(1000);
		factory.setPfmobile("8908765432");
		Thread.sleep(1000);
		factory.setPfcity("Pune");
		Thread.sleep(1000);
		factory.setPfstate("Maharashtra");
		Thread.sleep(1000);
		factory.setPfpersons(7);
		Thread.sleep(1000);
		factory.setPfcardholder("");
		Thread.sleep(1000);
		factory.setPfbutton();
	}

	@When("^user leaves DebitCardNo blank and clicks the button$")
	public void user_leaves_DebitCardNo_blank_and_clicks_the_button() throws Exception {
		factory.setPffname("Neelima");
		Thread.sleep(1000);
		factory.setPflname("Padmawar");
		Thread.sleep(1000);
		factory.setPfemail("neel.p@gmail.com");
		Thread.sleep(1000);
		factory.setPfmobile("8908765432");
		Thread.sleep(1000);
		factory.setPfcity("Pune");
		Thread.sleep(1000);
		factory.setPfstate("Maharashtra");
		Thread.sleep(1000);
		factory.setPfpersons(7);
		Thread.sleep(1000);
		factory.setPfcardholder("Neelima Padmawar");
		Thread.sleep(1000);
		factory.setPfdebit("");
		Thread.sleep(1000);
		factory.setPfbutton();
	}

	@When("^user leaves expirationMonth blank and clicks the button$")
	public void user_leaves_expirationMonth_blank_and_clicks_the_button() throws Exception {
		factory.setPffname("Neelima");
		Thread.sleep(1000);
		factory.setPflname("Padmawar");
		Thread.sleep(1000);
		factory.setPfemail("neel.p@gmail.com");
		Thread.sleep(1000);
		factory.setPfmobile("8908765432");
		Thread.sleep(1000);
		factory.setPfcity("Pune");
		Thread.sleep(1000);
		factory.setPfstate("Maharashtra");
		Thread.sleep(1000);
		factory.setPfpersons(7);
		Thread.sleep(1000);
		factory.setPfcardholder("Neelima Padmawar");
		Thread.sleep(1000);
		factory.setPfdebit("5678567867897890");
		Thread.sleep(1000);
		factory.setPfcvv("078");
		Thread.sleep(1000);
		factory.setPfmonth("");
		Thread.sleep(1000);
		factory.setPfbutton();
	}

	@When("^user leaves expirationYr blank and clicks the button$")
	public void user_leaves_expirationYr_blank_and_clicks_the_button() throws Exception {
		factory.setPffname("Neelima");
		Thread.sleep(1000);
		factory.setPflname("Padmawar");
		Thread.sleep(1000);
		factory.setPfemail("neel.p@gmail.com");
		Thread.sleep(1000);
		factory.setPfmobile("8908765432");
		Thread.sleep(1000);
		factory.setPfcity("Pune");
		Thread.sleep(1000);
		factory.setPfstate("Maharashtra");
		Thread.sleep(1000);
		factory.setPfpersons(7);
		Thread.sleep(1000);
		factory.setPfcardholder("Neelima Padmawar");
		Thread.sleep(1000);
		factory.setPfdebit("5678567867897890");
		Thread.sleep(1000);
		factory.setPfcvv("078");
		Thread.sleep(1000);
		factory.setPfmonth("6");
		Thread.sleep(1000);
		factory.setPfyear("");
		Thread.sleep(1000);
		factory.setPfbutton();
	}

	@After
	public void close() {
//		login.getBrowser().close();
		if(factory.getBrowser()!=null)
		factory.getBrowser().close();
	}

}
