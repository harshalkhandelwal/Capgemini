package com.example.demo.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.dto.ProductsCartDTO;
import com.example.demo.exception.InvalidModelExp;
import com.example.demo.repository.ProductsCartDAO;

@Service
public class ProductsCartServiceImpl implements ProductsCartService {
	
	@Autowired(required=true)
	ProductsCartDAO daoRef;

	@Override
	public List<ProductsCartDTO> viewProducts() {
		// TODO Auto-generated method stub
		return daoRef.viewProducts();
	}

	@Override
	public ProductsCartDTO createProduct(ProductsCartDTO productscartdto) {
		// TODO Auto-generated method stub
		String validModel=productscartdto.getModel();
		Pattern pt=Pattern.compile("^[a-zA-Z0-9]$");
		Matcher mat=pt.matcher(validModel);
		boolean r=mat.find();
		if(r==false)
			throw new InvalidModelExp();
		return daoRef.createProduct(productscartdto);
	}

	@Override
	public ProductsCartDTO findProduct(String id) {
		// TODO Auto-generated method stub
		return daoRef.findProduct(id);
	}

	@Override
	public ProductsCartDTO updateProduct(String id, ProductsCartDTO productscartdto) {
		// TODO Auto-generated method stub
		return daoRef.updateProduct(id, productscartdto);
	}

	@Override
	public ProductsCartDTO deleteProduct(String id) {
		// TODO Auto-generated method stub
		return daoRef.deleteProduct(id);
	}

}
