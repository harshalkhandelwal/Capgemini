package com.example.demo.repository;

import java.util.List;

import com.example.demo.dto.ProductsCartDTO;

public interface ProductsCartDAO {
	
	public List<ProductsCartDTO> viewProducts();
	public ProductsCartDTO createProduct(ProductsCartDTO productscartdto);
	public ProductsCartDTO findProduct(String id);
	public ProductsCartDTO updateProduct(String id, ProductsCartDTO productscartdto);
	public ProductsCartDTO deleteProduct(String id);

}
