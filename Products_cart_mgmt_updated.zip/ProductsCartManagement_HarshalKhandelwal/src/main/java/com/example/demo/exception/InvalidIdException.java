package com.example.demo.exception;

public class InvalidIdException extends RuntimeException {

}
