package com.example.demo.exception;

public class InvalidModelExp extends RuntimeException {

}
