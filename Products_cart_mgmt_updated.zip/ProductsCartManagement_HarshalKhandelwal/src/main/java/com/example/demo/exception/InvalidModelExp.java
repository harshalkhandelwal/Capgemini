package com.example.demo.exception;

//here we are creating user defined exception class and extending from RuntimeException class
public class InvalidModelExp extends RuntimeException {

}
