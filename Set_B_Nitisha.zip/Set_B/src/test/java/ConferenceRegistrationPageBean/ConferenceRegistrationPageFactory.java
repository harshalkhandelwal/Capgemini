package ConferenceRegistrationPageBean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ConferenceRegistrationPageFactory {
	WebDriver driver;

	@FindBy(name = "txtFN")
	@CacheLookup
	WebElement pffname;

	@FindBy(name = "txtLN")
	@CacheLookup
	WebElement pflname;

	@FindBy(name = "Email")
	@CacheLookup
	WebElement pfemail;

	@FindBy(css = "input[pattern='[789][0-9]{9}']")
	@CacheLookup
	WebElement pfphone;

	@FindBy(xpath = "html/body/form/table/tbody/tr[5]/td[2]/select/option[2]")
	@CacheLookup
	WebElement pfsize;

	@FindBy(name = "Address")
	@CacheLookup
	WebElement pfaddress;

	@FindBy(name = "Address2")
	@CacheLookup
	WebElement pfarea;

	@FindBy(name = "city")
	@CacheLookup
	WebElement pfcity;

	@FindBy(name = "state")
	@CacheLookup
	WebElement pfstate;

	@FindBy(name = "memberStatus")
	@CacheLookup
	WebElement pfstatus;

	@FindBy(xpath = "html/body/form/table/tbody/tr[14]/td/a")
	@CacheLookup
	WebElement pfnext;

	// After successful login, user navigate to payment details page.

	@FindBy(id = "txtCardholderName")
	@CacheLookup
	WebElement pfcardholdername;

	@FindBy(id = "txtDebit")
	@CacheLookup
	WebElement pfdebit;

	@FindBy(id = "txtCvv")
	@CacheLookup
	WebElement pfcvv;

	@FindBy(id = "txtMonth")
	@CacheLookup
	WebElement pfmonth;

	@FindBy(id = "txtYear")
	@CacheLookup
	WebElement pfyear;

	@FindBy(xpath = "//*[@id='btnPayment']")
	@CacheLookup
	WebElement pfbutton;

	// Getters

	public WebElement getPffname() {
		return pffname;
	}

	public WebElement getPflname() {
		return pflname;
	}

	public WebElement getPfemail() {
		return pfemail;
	}

	public WebElement getPfphone() {
		return pfphone;
	}

	public WebElement getPfsize() {
		return pfsize;
	}

	public WebElement getPfaddress() {
		return pfaddress;
	}

	public WebElement getPfarea() {
		return pfarea;
	}

	public WebElement getPfcity() {
		return pfcity;
	}

	public WebElement getPfstate() {
		return pfstate;
	}

	public WebElement getPfstatus() {
		return pfstatus;
	}

	public WebElement getPfnext() {
		return pfnext;
	}

	// After successful login, user navigate to payment details page.

	public WebElement getPfcardholdername() {
		return pfcardholdername;
	}

	public WebElement getPfdebit() {
		return pfdebit;
	}

	public WebElement getPfcvv() {
		return pfcvv;
	}

	public WebElement getPfmonth() {
		return pfmonth;
	}

	public WebElement getPfyear() {
		return pfyear;
	}

	public WebElement getPfbutton() {
		return pfbutton;
	}

	// Setters

	public void setPffname(String sffname) {
		pffname.sendKeys(sffname);
	}

	public void setPflname(String sflname) {
		pflname.sendKeys(sflname);
	}

	public void setPfemail(String sfemail) {
		pfemail.sendKeys(sfemail);
	}

	public void setPfphone(String sfphone) {
		pfphone.sendKeys(sfphone);
	}

	public void setPfsize() {
		pfsize.click();
	}

	public void setPfaddress(String sfaddress) {
		pfaddress.sendKeys(sfaddress);
	}

	public void setPfarea(String sfarea) {
		pfarea.sendKeys(sfarea);
	}

	public void setPfcity(String sfcity) {
		Select drpCity = new Select(pfcity);
		drpCity.selectByVisibleText(sfcity);
	}

	public void setPfstate(String sfstate) {
		Select drpState = new Select(pfstate);
		drpState.selectByVisibleText(sfstate);
	}

	public void setPfstatus(String sfstatus) {
		pfstatus = driver.findElement(By.xpath("html/body/form/table/tbody/tr[12]/td[2]/input"));
		pfstatus.click();
	}

	public void setPfnext() {
		pfnext.click();
	}

	// After successful login, user navigate to payment details page.

	public void setPfcardholdername(String sfcardholdername) {
		pfcardholdername.sendKeys(sfcardholdername);
	}

	public void setPfdebit(String sfdebit) {
		pfdebit.sendKeys(sfdebit);
	}

	public void setPfcvv(String sfcvv) {
		pfcvv.sendKeys(sfcvv);
	}

	public void setPfmonth(String sfmonth) {
		pfmonth.sendKeys(sfmonth);
	}

	public void setPfyear(String sfyear) {
		pfyear.sendKeys(sfyear);
	}

	public void setPfbutton() {
		pfbutton.click();
	}

	// Constructor

	public ConferenceRegistrationPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
