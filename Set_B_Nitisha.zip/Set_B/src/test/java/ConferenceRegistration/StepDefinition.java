package ConferenceRegistration;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import ConferenceRegistrationPageBean.ConferenceRegistrationPageFactory;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

	private WebDriver driver;
	private ConferenceRegistrationPageFactory objhbpg;

	@Given("^Open the browser and launch the application$")
	public void open_the_browser_and_launch_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NITISHAG\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objhbpg = new ConferenceRegistrationPageFactory(driver);
		driver.get("file:///C:/Users/NITISHAG/Desktop/mod/ConferenceRegistartion.html");
	}

	@Then("^Check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title = driver.getTitle();
		String pageHeading = driver.findElement(By.xpath("html/body/h2")).getText();
		System.out.println("Page Heading is : " + pageHeading);

		if (title.contentEquals("Conference Registration"))
			System.out.println("****** Title Matched******");
		else
			System.out.println("****** Title Not Matched******");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.close();
	}

	@Given("^User is on conference registration page$")
	public void user_is_on_conference_registration_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NITISHAG\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objhbpg = new ConferenceRegistrationPageFactory(driver);
		driver.get("file:///C:/Users/NITISHAG/Desktop/mod/ConferenceRegistartion.html");
	}

	@When("^User leaves First Name blank$")
	public void user_leaves_First_Name_blank() throws Throwable {
		objhbpg.setPffname("");
		Thread.sleep(1000);
	}

	@When("^Clicks the button$")
	public void clicks_the_button() throws Throwable {
		objhbpg.setPfnext();
	}

	@Then("^Displays the message$")
	public void displays_the_message() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("" + alertMessage);
		driver.close();
	}

	@When("^User leaves Last Name blank$")
	public void user_leaves_Last_Name_blank() throws Throwable {
		objhbpg.setPffname("Nitisha");
		Thread.sleep(1000);
		objhbpg.setPflname("");
		Thread.sleep(1000);
		// objhbpg.setPfnext();
	}

	@When("^User enters incorrect Email format$")
	public void user_enters_incorrect_Email_format() throws Throwable {
		objhbpg.setPffname("Nitisha");
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.ffh@fhj");
		Thread.sleep(1000);
		// objhbpg.setPfnext();
	}

	@When("^User leaves Contact No\\. blank$")
	public void user_leaves_Contact_No_blank() throws Throwable {
		objhbpg.setPffname("Nitisha");
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.k@gmail.com");
		Thread.sleep(1000);
		objhbpg.setPfphone("");
		Thread.sleep(1000);
	}

	@When("^user enters incorrect Contact No\\. format$")
	public void user_enters_incorrect_Contact_No_format() throws Throwable {
		objhbpg.setPffname("Nitisha");
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.a@gmail.com");
		Thread.sleep(1000);
		objhbpg.setPfphone("15234567890");
		Thread.sleep(1000);
	}

	@When("^User leaves Number of people attending blank$")
	public void user_leaves_Number_of_people_attending_blank() throws Throwable {
		objhbpg.setPffname("Nitisha");
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.a@gmail.com");
		Thread.sleep(1000);
		objhbpg.setPfphone("9897496567");
		Thread.sleep(1000);
		// objhbpg.setPfsize();
		Thread.sleep(1000);

	}

	@When("^User leaves building name and room no\\. blank$")
	public void user_leaves_building_name_and_room_no_blank() throws Throwable {
		objhbpg.setPffname("Nitisha");
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.a@gmail.com");
		Thread.sleep(1000);
		objhbpg.setPfphone("9897496567");
		Thread.sleep(1000);
		objhbpg.setPfsize();
		Thread.sleep(1000);
		objhbpg.setPfaddress("");
		Thread.sleep(1000);
	}

	@When("^User leaves area name blank$")
	public void user_leaves_area_name_blank() throws Throwable {
		objhbpg.setPffname("Nitisha");
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.a@gmail.com");
		Thread.sleep(1000);
		objhbpg.setPfphone("9897496567");
		Thread.sleep(1000);
		objhbpg.setPfsize();
		Thread.sleep(1000);
		objhbpg.setPfaddress("21, Capgemini");
		Thread.sleep(1000);
		objhbpg.setPfarea("");
		Thread.sleep(1000);
	}

	@When("^User leaves city blank$")
	public void user_leaves_city_blank() throws Throwable {
		objhbpg.setPffname("Nitisha");
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.a@gmail.com");
		Thread.sleep(1000);
		objhbpg.setPfphone("9897496567");
		Thread.sleep(1000);
		objhbpg.setPfsize();
		Thread.sleep(1000);
		objhbpg.setPfaddress("21, Capgemini");
		Thread.sleep(1000);
		objhbpg.setPfarea("Talawade");
		Thread.sleep(1000);
		objhbpg.setPfcity("Select City");
		Thread.sleep(1000);
	}

	@When("^User leaves state blank$")
	public void user_leaves_state_blank() throws Throwable {
		objhbpg.setPffname("Nitisha");
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.a@gmail.com");
		Thread.sleep(1000);
		objhbpg.setPfphone("9897496567");
		Thread.sleep(1000);
		objhbpg.setPfsize();
		Thread.sleep(1000);
		objhbpg.setPfaddress("21, Capgemini");
		Thread.sleep(1000);
		objhbpg.setPfarea("Talawade");
		Thread.sleep(1000);
		objhbpg.setPfcity("Pune");
		Thread.sleep(1000);
		objhbpg.setPfstate("Select State");
		Thread.sleep(1000);
	}

	@When("^User leaves Conference full-Access\\(member\\) or Conference full-Access\\(non-member\\) blank$")
	public void user_leaves_Conference_full_Access_member_or_Conference_full_Access_non_member_blank()
			throws Throwable {
		objhbpg.setPffname("Nitisha");
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.a@gmail.com");
		Thread.sleep(1000);
		objhbpg.setPfphone("9897496567");
		Thread.sleep(1000);
		objhbpg.setPfsize();
		Thread.sleep(1000);
		objhbpg.setPfaddress("21, Capgemini");
		Thread.sleep(1000);
		objhbpg.setPfarea("Talawade");
		Thread.sleep(1000);
		objhbpg.setPfcity("Pune");
		Thread.sleep(1000);
		objhbpg.setPfstate("Maharashtra");
		Thread.sleep(1000);
		objhbpg.setPfstatus("");
		Thread.sleep(1000);
	}

	@When("^User enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		objhbpg.setPffname("Nitisha");
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.a@gmail.com");
		Thread.sleep(1000);
		objhbpg.setPfphone("9897496567");
		Thread.sleep(1000);
		objhbpg.setPfsize();
		Thread.sleep(1000);
		objhbpg.setPfaddress("21, Capgemini");
		Thread.sleep(1000);
		objhbpg.setPfarea("Talawade");
		Thread.sleep(1000);
		objhbpg.setPfcity("Pune");
		Thread.sleep(1000);
		objhbpg.setPfstate("Maharashtra");
		Thread.sleep(1000);
		objhbpg.setPfstatus("Conference full-Access(member)(1000 Rs.)");
		Thread.sleep(1000);
		// objhbpg.setPfnext();
	}

	@Then("^Navigate to Payment Details page$")
	public void navigate_to_Payment_Details_page() throws Throwable {
		driver.navigate().to("file:///C:/Users/NITISHAG/Desktop/mod/PaymentDetails.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	// After successful login, user navigate to payment details page.

	@Given("^User is on Payment Details page$")
	public void user_is_on_Payment_Details_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NITISHAG\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objhbpg = new ConferenceRegistrationPageFactory(driver);
		driver.get("file:///C:/Users/NITISHAG/Desktop/mod/PaymentDetails.html");
	}

	@When("^user leaves CardHolderName blank$")
	public void user_leaves_CardHolderName_blank() throws Throwable {
		objhbpg.setPfcardholdername("");
		Thread.sleep(1000);

	}

	@When("^click the button$")
	public void click_the_button() throws Throwable {
		objhbpg.setPfbutton();

	}

	@Then("^display msg$")
	public void display_msg() throws Throwable {
		String alertMessages = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("" + alertMessages);
		driver.close();
	}

	@When("^user leaves DebitCardNo blank$")
	public void user_leaves_DebitCardNo_blank() throws Throwable {
		objhbpg.setPfcardholdername("Nitisha Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfdebit("");
		Thread.sleep(1000);
	}

	@When("^user leaves expiration Month blank$")
	public void user_leaves_expiration_Month_blank() throws Throwable {
		objhbpg.setPfcardholdername("Nitisha Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfdebit("8765431234567898");
		Thread.sleep(1000);
		objhbpg.setPfcvv("098");
		Thread.sleep(1000);
		objhbpg.setPfmonth("");
		Thread.sleep(1000);
	}

	@When("^user leaves expiration year blank$")
	public void user_leaves_expiration_year_blank() throws Throwable {
		objhbpg.setPfcardholdername("Nitisha Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfdebit("7678567867897890");
		Thread.sleep(1000);
		objhbpg.setPfcvv("056");
		Thread.sleep(1000);
		objhbpg.setPfmonth("08");
		Thread.sleep(1000);
		objhbpg.setPfyear("");
		Thread.sleep(1000);
	}

	@When("^User enters all the valid data$")
	public void user_enters_all_the_valid_data() throws Throwable {
		objhbpg.setPfcardholdername("Nitisha Agrawal");
		Thread.sleep(1000);
		objhbpg.setPfdebit("7678567867897890");
		Thread.sleep(1000);
		objhbpg.setPfcvv("056");
		Thread.sleep(1000);
		objhbpg.setPfmonth("08");
		Thread.sleep(1000);
		objhbpg.setPfyear("23");
		Thread.sleep(1000);
		// objhbpg.setPfbutton();

	}
}
